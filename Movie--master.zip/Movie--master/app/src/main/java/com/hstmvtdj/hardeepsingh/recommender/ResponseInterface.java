package com.hstmvtdj.hardeepsingh.recommender;

/**
 * Created by hardeepsingh on 4/29/17.
 */

public interface ResponseInterface {
    void onDataRecieved(String json);
}
